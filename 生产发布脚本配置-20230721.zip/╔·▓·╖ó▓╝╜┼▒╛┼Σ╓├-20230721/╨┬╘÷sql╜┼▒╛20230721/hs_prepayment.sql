/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.11.76--恒生dev
 Source Server Type    : PostgreSQL
 Source Server Version : 110007
 Source Host           : 192.168.11.76:5432
 Source Catalog        : hswo
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 110007
 File Encoding         : 65001

 Date: 20/07/2023 10:18:26
*/


-- ----------------------------
-- Table structure for hs_prepayment
-- ----------------------------
DROP TABLE IF EXISTS "public"."hs_prepayment";
CREATE TABLE "public"."hs_prepayment" (
  "serial_number" varchar(30) COLLATE "pg_catalog"."default" NOT NULL DEFAULT NULL,
  "application_time" varchar(30) COLLATE "pg_catalog"."default" NOT NULL DEFAULT NULL,
  "branch_name" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "consumer_loans" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "currency_type" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_level" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_name" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_no" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "hs_account" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "loan_account" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "loan_balance" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "repayment_amount" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "repayment_date" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "repayment_reason" varchar(10) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "rm_code" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "service_category" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "source_funds" varchar(255) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "source_funds_detail" varchar(255) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "telephone" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "status" varchar(20) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "business_type" varchar(32) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "operater" varchar(40) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "work_id" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "other_telephone" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "partial_repayment_categories" varchar(10) COLLATE "pg_catalog"."default" DEFAULT NULL
)
;
COMMENT ON COLUMN "public"."hs_prepayment"."other_telephone" IS '其他联系方式';
COMMENT ON COLUMN "public"."hs_prepayment"."partial_repayment_categories" IS '部分还款类别 (001)减少月供/(002) 减少期数';

-- ----------------------------
-- Primary Key structure for table hs_prepayment
-- ----------------------------
ALTER TABLE "public"."hs_prepayment" ADD CONSTRAINT "hs_prepayment_pkey" PRIMARY KEY ("serial_number");
