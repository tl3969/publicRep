ALTER TABLE hs_work_order  DROP COLUMN work_type;
DROP TABLE hs_supplementary_billing;
DROP TABLE hs_prepayment
